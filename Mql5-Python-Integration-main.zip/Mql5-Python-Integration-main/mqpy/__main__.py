"""Main entry point for the MQL5-Python integration package."""

from .template import main

if __name__ == "__main__":
    main()
