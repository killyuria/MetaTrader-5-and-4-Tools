"""Scripts for the project."""
