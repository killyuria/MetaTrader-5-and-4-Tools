"""Example package for MQPy demonstration code."""
