"""FiMathe strategy examples for MetaTrader 5.

This package contains examples of Expert Advisors using Fibonacci retracement levels.
"""
